Original Relax NG Schemas taked from "https://www.oasis-open.org/committees/tc_home.php?wg_abbrev=office":
OpenDocument-manifest-schema-v1.1.rng
OpenDocument-schema-v1.1.rng
OpenDocument-strict-schema-v1.1.rng


OpenDocument-schema-v1.1.rng Relax NG Schema automatically transformed to xsd:
anim.xsd
chart.xsd
config.xsd
dc.xsd
dr3d.xsd
draw.xsd
fo.xsd
form.xsd
math.xsd
meta.xsd
number.xsd
office.xsd
OpenDocument-schema-v1.1 OriginalTransformed.xsd
presentation.xsd
script.xsd
smil.xsd
style.xsd
svg.xsd
table.xsd
xforms.xsd
xlink.xsd


This automatically transformed files contains transforming approximations and errors and further will be edited. Edited versions of this files will be named with pattern "odf-*.xsd" in root "schemas\" folder.
Transformating is performed with "disable-abstract-elemnts" option to avoid abstract elements.
